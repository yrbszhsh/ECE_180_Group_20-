import gmplot
import pandas as pd
import ast
import matplotlib
import matplotlib.animation as animation
import matplotlib.pyplot as plt


info = pd.read_csv('sandiego_trafficdata.csv')
point_1 = info['Co1']
point_2 = info['Co2']
l = len(point_1)

years = ['2011','2012','2013','2014','2015']

im = []
fig = plt.figure(figsize=(10, 10))

for j in years:
	v_y = info[j]
	v_y_nor = []
	min_y = min(v_y)
	max_y = max(v_y)
	for i in range(l):
		normalize = float(v_y[i] - min_y)/(max_y-min_y)
		v_y_nor.append(normalize)

	# Place map
	gmap = gmplot.GoogleMapPlotter(32.7297996,-117.0762559,10)

	for i in range(l):
		lats, lons = zip(*[
		ast.literal_eval(point_1[i]),
		ast.literal_eval(point_2[i])
		])
		if v_y_nor[i] <= 0.2/3:
			color = 'green'
		elif v_y_nor[i] <= 1.0/3 and v_y_nor[i] > 0.2/3:
			color = 'orange'
		elif v_y_nor[i] <= 3.0/3:
			color = 'red'
		gmap.scatter(lats, lons, color, size=1)

	gmap.draw("sd_%s.html" % j)
	im.append(gmap)

#ani = animation.ArtistAnimation(fig, im, interval=500, blit=False, repeat_delay=1)
#ani.save('dynamic_images.mp4')
#plt.show()


